/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DEMO;

/**
 *
 * @author Dulce Yadira
 */
import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Cliente {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        try {
            Registry miRegistro = LocateRegistry.getRegistry("localhost", 1099);
            Calculadora c = (Calculadora) Naming.lookup("//localhost/Calculadora");
            
            while (true) {
                String menu = JOptionPane.showInputDialog("UACAM\nSistemas Distribuidos\n"+ "Ejercicio calculadora \n" +  "Suma ....(1) \n" + "Resta....(2) \n" + "Multiplicacion....(3) \n" + "Division...(4) \n\n" + "Cancelar para salir");                
                switch (menu) {
                    case "1":
                        {
                            int x = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el primer numero"));
                            int y = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el segundo numero"));
                            JOptionPane.showMessageDialog(null, "La suma es: " +c.add(x,y));
                            break;
                        }
                    case "2":
                        {
                            int x = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el primer numero"));
                            int y = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el segundo numero"));
                            JOptionPane.showMessageDialog(null, "La resta es: " +c.sub(x,y));
                            break;
                        }
                    case "3":
                        {
                            int x = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el primer numero"));
                            int y = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el segundo numero"));
                            JOptionPane.showMessageDialog(null, "La multiplicacion es: " +c.mul(x,y));
                            break;
                        }
                    case "4":
                        {
                            int x = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el primer numero"));
                            int y = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el segundo numero"));
                            JOptionPane.showMessageDialog(null, "La division es: " +c.div(x,y));
                            break;
                        }
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Servidor no conectado " + e);
        }
    }
}
